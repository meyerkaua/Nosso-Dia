const contador = document.getElementById("contador");

function atualizarContador() {
  const dataInicio = new Date("2025-02-23T16:30:00");
  const agora = new Date();
  const diff = agora - dataInicio;

  const dias = Math.floor(diff / (1000 * 60 * 60 * 24));
  const horas = Math.floor((diff / (1000 * 60 * 60)) % 24);
  const minutos = Math.floor((diff / (1000 * 60)) % 60);
  const segundos = Math.floor((diff / 1000) % 60);

  contador.textContent = `${dias} dias, ${horas} horas, ${minutos} minutos e ${segundos} segundos.`;
}

setInterval(atualizarContador, 1000);
atualizarContador();

const botaoMusica = document.getElementById("botaoMusica");
const audio = document.getElementById("audio");
let tocando = false;

botaoMusica.addEventListener("click", () => {
  if (!tocando) {
    audio.play();
    botaoMusica.textContent = "⏸️ Pausar Música";
  } else {
    audio.pause();
    botaoMusica.textContent = "🎵 Tocar Música";
  }
  tocando = !tocando;
});
